/*
 * T4Bis.cpp
 *
 *  Created on: 17 de abr. de 2016
 *      Author: Jorge
 */
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <iostream>
#include <unistd.h>
#include <math.h>
#include <opencv2/stitching/warpers.hpp>
#include <opencv2/stitching/stitcher.hpp>

using namespace std;
using namespace cv;

int calcMinMax(vector<vector<Point2f> > objs, vector<Point2f> core,
		vector<float>* sal) {
	float minX = numeric_limits<int>::max();
	float minY = numeric_limits<int>::max();
	float maxX = -numeric_limits<int>::max();
	float maxY = -numeric_limits<int>::max();
	for (int j = 0; j < objs.size(); ++j) {
		vector<Point2f> obj = objs.at(j);
		for (int i = 0; i < 4; ++i) {
			float objX = obj[i].x;
			float objY = obj[i].y;
			float coreX = core[i].x;
			float coreY = core[i].y;
			(objX < minX) ? (minX = objX) : (minX);
			(objX > maxX) ? (maxX = objX) : (maxX);
			(objY < minY) ? (minY = objY) : (minY);
			(objY > maxY) ? (maxY = objY) : (maxY);
			(coreX < minX) ? (minX = coreX) : (minX);
			(coreX > maxX) ? (maxX = coreX) : (maxX);
			(coreY < minY) ? (minY = coreY) : (minY);
			(coreY > maxY) ? (maxY = coreY) : (maxY);
		}
	}
	sal->at(0) = minX;
	sal->at(1) = maxX;
	sal->at(2) = minY;
	sal->at(3) = maxY;
}

int main() {
	vector<Mat> imgsBN;
	vector<Mat> imgsCL;
	/* Reads the images */
	Mat img1 = imread("imagenes/Aldea1.jpg", CV_LOAD_IMAGE_COLOR);
	Mat img2 = imread("imagenes/Aldea2.jpg", CV_LOAD_IMAGE_COLOR);
	Mat img3 = imread("imagenes/Aldea3.jpg", CV_LOAD_IMAGE_COLOR);
	//Mat img4 = imread("imagenes/Torre4.jpg", CV_LOAD_IMAGE_COLOR);
	resize(img1, img1, Size(img1.cols, img1.rows));
	resize(img2, img2, Size(img2.cols, img2.rows));
	resize(img3, img3, Size(img3.cols, img3.rows));
	imgsCL.push_back(img1);
	//imgsCL.push_back(img2);
	imgsCL.push_back(img3);
	//imgsCL.push_back(img4);
	Mat img1G, img2G, img3G, img4G;
	cvtColor(img1, img1G, CV_RGB2GRAY);
	cvtColor(img2, img2G, CV_RGB2GRAY);
	cvtColor(img3, img3G, CV_RGB2GRAY);
	//cvtColor(img4, img4G, CV_RGB2GRAY);
	imgsBN.push_back(img1G);
	//imgsBN.push_back(img2G);
	imgsBN.push_back(img3G);
	//imgsBN.push_back(img4G);

	Stitcher::createDefault(true);
	Stitcher::Status status = Stitcher::estimateTransform(&imgsCL);

	Mat coreCL = img2;
	for (int ind = 0; ind < imgsBN.size(); ++ind) {
		Mat core;
		Mat add = imgsBN.at(ind);
		Mat addCL = imgsCL.at(ind);
		cvtColor(coreCL, core, CV_RGB2GRAY);
		//resize(core, core, Size(core.cols*0.5, core.rows*0.5));
		//resize(add, add, Size(add.cols*0.5, add.rows*0.5));
		//resize(coreCL, coreCL, Size(coreCL.cols*0.5, coreCL.rows*0.5));
		//resize(addCL, addCL, Size(addCL.cols*0.5, addCL.rows*0.5));

		/* Detects the keypoints with a feature detector */
		SurfFeatureDetector detector(600);	// Usar NORM_L2 en BFMatcher
		//OrbFeatureDetector detector(600);	// Usar NORM_HAMMING en BFMatcher
		//SiftFeatureDetector detector(600);	// Usar NORM_L2 en BFMatcher
		vector<KeyPoint> keypointsCore, keypointsAdd;
		detector.detect(core, keypointsCore);
		detector.detect(add, keypointsAdd);

		/* Extracts the descriptors from the features */
		SurfDescriptorExtractor extractor;
		//OrbDescriptorExtractor extractor;
		//SiftDescriptorExtractor extractor;
		Mat descriptorsCore, descriptorsAdd;
		extractor.compute(core, keypointsCore, descriptorsCore);
		extractor.compute(add, keypointsAdd, descriptorsAdd);

		/* Finds matches between both images */
		BFMatcher matcher(NORM_L2);	// Usar NORM correspondiente a detector
		//FlannBasedMatcher matcher;	// Mas rapido que fuerza bruta
		vector<vector<DMatch> > matches;
		matcher.knnMatch(descriptorsAdd, descriptorsCore, matches, 2);

		/* Only good matches are preserved (2nd neighbor ratio) */
		vector<DMatch> good_matches;
		for (int i = 0; i < (int) matches.size(); i++) {
			float d1 = matches.at(i).at(0).distance;
			float d2 = matches.at(i).at(1).distance;
			if (d1 < d2 * 0.7) {	// Ratio 2 vecino (ir variando)
				good_matches.push_back(matches.at(i).at(0));
			}
		}

		Mat img_matches;
		drawMatches(add, keypointsAdd, core, keypointsCore, good_matches,
				img_matches);

		/* Localize the object */
		vector<Point2f> picCoreAdd;
		vector<Point2f> picAddCore;
		vector<Point2f> pic23;
		vector<Point2f> pic32;
		for (int i = 0; i < (int) good_matches.size(); i++) {
			/* Get the keypoints from the good matches */
			picCoreAdd.push_back(keypointsAdd[good_matches[i].queryIdx].pt);
			picAddCore.push_back(keypointsCore[good_matches[i].trainIdx].pt);
		}

		if (good_matches.size() >= 4) {
			Mat H = findHomography(picCoreAdd, picAddCore, CV_RANSAC);

			/* Get the corners from the image_1 ( the object to be "detected" ) */
			vector<Point2f> obj_corners12(4);
			vector<Point2f> core_corners(4);
			obj_corners12[0] = cvPoint(0, 0);
			obj_corners12[1] = cvPoint(add.cols, 0);
			obj_corners12[2] = cvPoint(add.cols, add.rows);
			obj_corners12[3] = cvPoint(0, add.rows);

			core_corners[0] = cvPoint(0, 0);
			core_corners[1] = cvPoint(core.cols, 0);
			core_corners[2] = cvPoint(core.cols, core.rows);
			core_corners[3] = cvPoint(0, core.rows);

			vector<Point2f> scene_corners12(4);
			perspectiveTransform(obj_corners12, scene_corners12, H);

			/* Draw lines between the corners (the mapped object in the scene - image_2 ) */
			line(img_matches, scene_corners12[0] + Point2f(add.cols, 0),
					scene_corners12[1] + Point2f(add.cols, 0),
					Scalar(0, 255, 0), 4);
			line(img_matches, scene_corners12[1] + Point2f(add.cols, 0),
					scene_corners12[2] + Point2f(add.cols, 0),
					Scalar(0, 255, 0), 4);
			line(img_matches, scene_corners12[2] + Point2f(add.cols, 0),
					scene_corners12[3] + Point2f(add.cols, 0),
					Scalar(0, 255, 0), 4);
			line(img_matches, scene_corners12[3] + Point2f(add.cols, 0),
					scene_corners12[0] + Point2f(add.cols, 0),
					Scalar(0, 255, 0), 4);

			vector<vector<Point2f> > scenes; /* Numero random xD en dinámico habra que hacerlo dinámico */
			scenes.push_back(scene_corners12);
			vector<float> minMax(4);
			calcMinMax(scenes, core_corners, &minMax);
			int width = minMax[1] - minMax[0];
			int height = minMax[3] - minMax[2];

			Mat T = Mat::eye(3, 3, CV_64FC1);
			if (minMax[0] < 0) {
				T.at<double>(0, 2) = -minMax[0];
			}
			if (minMax[2] < 0) {
				T.at<double>(1, 2) = -minMax[2];
			}

			/* Use the Homography Matrix to warp the images */
			Mat result;
			result = Mat(Size(width, height), CV_32F);
			warpPerspective(coreCL, result, T, result.size(), INTER_LINEAR,
					BORDER_TRANSPARENT);
			warpPerspective(addCL, result, T * H, result.size(), INTER_LINEAR,
					BORDER_TRANSPARENT);
			//warpPerspective(img2,result,T,result.size(), INTER_LINEAR, BORDER_TRANSPARENT);
			//Mat half(result,cv::Rect(0,0,img2.cols,img2.rows));
			//warpPerspective(img2,result2,H1,Size(img2.cols,img2.rows));
			//result2.copyTo(half);

			Mat coreShow, addShow;
			resize(core, coreShow, Size(core.cols*0.5, core.rows*0.5));
			resize(add, addShow, Size(add.cols*0.5, add.rows*0.5));
			imshow("Core", coreShow);
			imshow("Add", addShow);

			Mat show = result;
			resize(show, show, Size(show.cols * 0.5, show.rows * 0.5));
			imshow("Result", show);
			coreCL = result;

			/* Show detected matches */
			Mat matchesShow;
			resize(img_matches, matchesShow, Size(img_matches.cols * 0.5, img_matches.rows * 0.5));
			imshow("Good Matches & Object detection 1->2", matchesShow);

			waitKey(0);
		}
	}

}

