#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <iostream>
#include <unistd.h>
#include <math.h>

using namespace std;
using namespace cv;

Mat Ransac(vector<Point2f> picCoreAdd, vector<Point2f> picAddCore) {
	vector<Point2f> random_choice_core;
	vector<Point2f> random_choice_add;
	Mat H;
	srand(time(NULL));

	vector<Point2f> consensus_core;
	vector<Point2f> consensus_add;
	int epsilon = 5;
	int umbral_consenso = 5;
	int conjunto_consenso = 0;
	//while (conjunto_consenso < umbral_consenso) {
		conjunto_consenso = 0;

		/* Elige 4 matchings al azar */
		for (int i=0; i<4; i++) {
			int index = rand() % picCoreAdd.size();
			random_choice_core.push_back(picCoreAdd.at(index));
			random_choice_add.push_back(picAddCore.at(index));
			//cout << "Elegidos " << picCoreAdd.at(index) << " " << picAddCore.at(index) << endl;
		}

		/* Calcula el modelo con esos 4 puntos */
		H = findHomography(random_choice_core, random_choice_add, 0);
		//cout << H.at<float>(Point(0,0)) << " " << H.at<float>(Point(0,1)) << " " << H.at<float>(Point(0,2)) << endl;
		//cout << H.at<float>(Point(1,0)) << " " << H.at<float>(Point(1,1)) << " " << H.at<float>(Point(1,2)) << endl;
		//cout << H.at<float>(Point(2,0)) << " " << H.at<float>(Point(2,1)) << " " << H.at<float>(Point(2,2)) << endl;

		/* Aplica ese modelo a todos los puntos */
		vector<Point2f> result(picCoreAdd.size());
		perspectiveTransform(picCoreAdd, result, H);

		for (int i=0; i<(int)result.size(); i++) {
			//cout << result.at(i) << " " << picAddCore.at(i) << endl;
			cout << picCoreAdd.at(i) << " " << picAddCore.at(i) << " " << result.at(i) << endl;
		}
		//cout << result.size() << endl;

		/* Calcula cuantos matchings son compatibles con este modelo */
		for (int i=0; i<(int)picAddCore.size(); i++) {
			Point2f real = picAddCore.at(i);
			Point2f obtained = result.at(i);

			/* Calcula distancia entre el matching real y el obtenido */
			double dist = sqrt(pow(real.x - obtained.x, 2) + (pow(real.y - obtained.y, 2)));
			if (dist < epsilon) {
				conjunto_consenso++;
				consensus_core.push_back(picCoreAdd.at(i));
				consensus_add.push_back(result.at(i));
			}
		}
	//}
	cout << conjunto_consenso << endl;

	/* Calcula la homografia sobre el conjunto consenso */
	H = findHomography(consensus_core, consensus_add, 0);

	return H;

}
