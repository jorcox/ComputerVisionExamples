#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include <iostream>
#include <unistd.h>
#include <math.h>

using namespace std;
using namespace cv;

int calcMinMax(vector<vector<Point2f> > objs, vector<Point2f> core,
		vector<float>* sal) {
	float minX = numeric_limits<int>::max();
	float minY = numeric_limits<int>::max();
	float maxX = -numeric_limits<int>::max();
	float maxY = -numeric_limits<int>::max();
	for (int j = 0; j < 2; ++j) {
		vector<Point2f> obj = objs[j];
		for (int i = 0; i < 4; ++i) {
			float objX = obj[i].x;
			float objY = obj[i].y;
			float coreX = core[i].x;
			float coreY = core[i].y;
			(objX < minX) ? (minX = objX) : (minX);
			(objX > maxX) ? (maxX = objX) : (maxX);
			(objY < minY) ? (minY = objY) : (minY);
			(objY > maxY) ? (maxY = objY) : (maxY);
			(coreX < minX) ? (minX = coreX) : (minX);
			(coreX > maxX) ? (maxX = coreX) : (maxX);
			(coreY < minY) ? (minY = coreY) : (minY);
			(coreY > maxY) ? (maxY = coreY) : (maxY);
		}
	}

	sal->at(0) = minX;
	sal->at(1) = maxX;
	sal->at(2) = minY;
	sal->at(3) = maxY;
}

int main() {
	/* Reads the images */
	Mat img1 = imread("imagenes/Torre1.jpg", CV_LOAD_IMAGE_COLOR);
	Mat img2 = imread("imagenes/Torre2.jpg", CV_LOAD_IMAGE_COLOR);
	Mat img3 = imread("imagenes/Torre3.jpg", CV_LOAD_IMAGE_COLOR);
	resize(img1, img1, Size(img1.cols, img1.rows));
	resize(img2, img2, Size(img2.cols*0.3, img2.rows*0.3));
	resize(img3, img3, Size(img3.cols, img3.rows));

	/* Detects the keypoints with a feature detector */
	//SurfFeatureDetector detector(600);	// Usar NORM_L2 en BFMatcher
	//OrbFeatureDetector detector(100);	// Usar NORM_HAMMING en BFMatcher
	SiftFeatureDetector detector(300);	// Usar NORM_L2 en BFMatcher
	vector<KeyPoint> keypoints1, keypoints2, keypoints3;
	detector.detect(img1, keypoints1);
	detector.detect(img2, keypoints2);
	detector.detect(img3, keypoints3);

	/* Extracts the descriptors from the features */
	//SurfDescriptorExtractor extractor;
	//OrbDescriptorExtractor extractor;
	SiftDescriptorExtractor extractor;
	Mat descriptors1, descriptors2, descriptors3;
	extractor.compute(img1, keypoints1, descriptors1);
	extractor.compute(img2, keypoints2, descriptors2);
	extractor.compute(img3, keypoints3, descriptors3);

	/* Finds matches between both images */
	BFMatcher matcher(NORM_L2);	// Usar NORM correspondiente a detector
	//FlannBasedMatcher matcher;	// Mas rapido que fuerza bruta
	vector<vector<DMatch> > matches1, matches2;
	matcher.knnMatch(descriptors1, descriptors2, matches1, 2);
	matcher.knnMatch(descriptors2, descriptors3, matches2, 2);

	/* Only good matches are preserved (2nd neighbor ratio) */
	vector<DMatch> good_matches1, good_matches2;
	for (int i = 0; i < (int) matches1.size(); i++) {
		float d1 = matches1.at(i).at(0).distance;
		float d2 = matches1.at(i).at(1).distance;
		if (d1 < d2 * 0.7) {	// Ratio 2 vecino (ir variando)
			good_matches1.push_back(matches1.at(i).at(0));
		}
	}

	for (int i = 0; i < (int) matches2.size(); i++) {
		float d1 = matches2.at(i).at(0).distance;
		float d2 = matches2.at(i).at(1).distance;
		if (d1 < d2 * 0.7) {	// Ratio 2 vecino (ir variando)
			good_matches2.push_back(matches2.at(i).at(0));
		}
	}

	imshow("img1", img1);
	imshow("img2", img2);
	imshow("img3", img3);

	Mat img_matches1, img_matches2;
	drawMatches(img1, keypoints1, img2, keypoints2, good_matches1,
			img_matches1);
	drawMatches(img2, keypoints2, img3, keypoints3, good_matches2,
			img_matches2);

	/* Localize the object */
	vector<Point2f> pic12;
	vector<Point2f> pic21;
	vector<Point2f> pic23;
	vector<Point2f> pic32;
	for (int i = 0; i < good_matches1.size(); i++) {
		/* Get the keypoints from the good matches */
		pic12.push_back(keypoints1[good_matches1[i].queryIdx].pt);
		pic21.push_back(keypoints2[good_matches1[i].trainIdx].pt);
	}
	for (int i = 0; i < good_matches2.size(); i++) {
		/* Get the keypoints from the good matches */
		pic23.push_back(keypoints2[good_matches2[i].queryIdx].pt);
		pic32.push_back(keypoints3[good_matches2[i].trainIdx].pt);
	}

	if (good_matches1.size() >= 4 && good_matches2.size() >= 4) {
		Mat H1 = findHomography(pic12, pic21, CV_RANSAC);
		Mat H2 = findHomography(pic32, pic23, CV_RANSAC);

		/* Get the corners from the image_1 ( the object to be "detected" ) */
		vector<Point2f> obj_corners12(4);
		vector<Point2f> obj_corners23(4);
		vector<Point2f> core_corners(4);
		obj_corners12[0] = cvPoint(0, 0);
		obj_corners12[1] = cvPoint(img1.cols, 0);
		obj_corners12[2] = cvPoint(img1.cols, img1.rows);
		obj_corners12[3] = cvPoint(0, img1.rows);

		core_corners[0] = cvPoint(0, 0);
		core_corners[1] = cvPoint(img2.cols, 0);
		core_corners[2] = cvPoint(img2.cols, img2.rows);
		core_corners[3] = cvPoint(0, img2.rows);

		obj_corners23[0] = cvPoint(0, 0);
		obj_corners23[1] = cvPoint(img2.cols, 0);
		obj_corners23[2] = cvPoint(img2.cols, img2.rows);
		obj_corners23[3] = cvPoint(0, img2.rows);

		vector<Point2f> scene_corners12(4);
		vector<Point2f> scene_corners23(4);
		perspectiveTransform(obj_corners12, scene_corners12, H1);
		perspectiveTransform(obj_corners23, scene_corners23, H2);

		/* Draw lines between the corners (the mapped object in the scene - image_2 ) */
		line(img_matches1, scene_corners12[0] + Point2f(img1.cols, 0),
				scene_corners12[1] + Point2f(img1.cols, 0), Scalar(0, 255, 0),
				4);
		line(img_matches1, scene_corners12[1] + Point2f(img1.cols, 0),
				scene_corners12[2] + Point2f(img1.cols, 0), Scalar(0, 255, 0),
				4);
		line(img_matches1, scene_corners12[2] + Point2f(img1.cols, 0),
				scene_corners12[3] + Point2f(img1.cols, 0), Scalar(0, 255, 0),
				4);
		line(img_matches1, scene_corners12[3] + Point2f(img1.cols, 0),
				scene_corners12[0] + Point2f(img1.cols, 0), Scalar(0, 255, 0),
				4);

		vector<vector<Point2f> > scenes(12); /* Numero random xD en dinámico habra que hacerlo dinámico */
		scenes[0] = scene_corners12;
		scenes[1] = scene_corners23;
		vector<float> minMax(4);
		calcMinMax(scenes, core_corners, &minMax);
		int width = minMax[1] - minMax[0];
		int height = minMax[3] - minMax[2];

		Mat T = Mat::eye(3, 3, CV_64FC1);
		if (minMax[0] < 0) {
			T.at<double>(0, 2) = -minMax[0];
		}
		if (minMax[2] < 0) {
			T.at<double>(1, 2) = -minMax[2];
		}

		//Mat HN = H1 * T;
		//HN = HN.inv();

		line(img_matches2, scene_corners23[0], scene_corners23[1],
				Scalar(0, 255, 0), 4);
		line(img_matches2, scene_corners23[1], scene_corners23[2],
				Scalar(0, 255, 0), 4);
		line(img_matches2, scene_corners23[2], scene_corners23[3],
				Scalar(0, 255, 0), 4);
		line(img_matches2, scene_corners23[3], scene_corners23[0],
				Scalar(0, 255, 0), 4);

		/* Use the Homography Matrix to warp the images */
		Mat result;
		result = Mat(Size(width, height), CV_32F);
		warpPerspective(img2, result, T, result.size(), INTER_LINEAR,
				BORDER_TRANSPARENT);
		warpPerspective(img1, result, T * H1, result.size(), INTER_LINEAR,
				BORDER_TRANSPARENT);
		warpPerspective(img3, result, T * H2, result.size(), INTER_LINEAR,
				BORDER_TRANSPARENT);
		//warpPerspective(img2,result,T,result.size(), INTER_LINEAR, BORDER_TRANSPARENT);
		//Mat half(result,cv::Rect(0,0,img2.cols,img2.rows));
		//warpPerspective(img2,result2,H1,Size(img2.cols,img2.rows));
		//result2.copyTo(half);

		resize(result, result, Size(result.cols * 0.8, result.rows * 0.8));
		imshow("Result", result);

		/* Show detected matches */
		imshow("Good Matches & Object detection 1->2", img_matches1);
		imshow("Good Matches & Object detection 2->3", img_matches2);

		waitKey(0);
	}

}
